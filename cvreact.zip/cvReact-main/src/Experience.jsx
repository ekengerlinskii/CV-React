import React, { Component } from 'react'

import './App.css'

class A extends Component{  

    render(){     
        
       
        return(
          <div>
             <h1>Опыт работы : </h1>
             <h2>2019: Cisco IT Help desk</h2>
             <h2>2020: System Administartor Pasha Holding</h2>
             <h2>2021: Communication Engineer in Caspel </h2>
          </div>
        )
    }
}

export default A