import React, { Component } from 'react'
import './App.css'
class Contacts extends Component {
    
    render() { 
        return (
            <div>
                <h1>Телефон: +994553054006</h1>
                <h1>E-mail: teymur.valikhan99@gmail.com</h1>
            </div>
        );
    }
}
 
export default Contacts;